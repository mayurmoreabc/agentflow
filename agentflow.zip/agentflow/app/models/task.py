"""
task.py — Domain Models for Task Lifecycle

WHY PYDANTIC MODELS:
    Pydantic v2 models serve as our contract layer between the API,
    the orchestrator, and the agents. They enforce data integrity at
    runtime, auto-generate OpenAPI docs, and make our codebase
    self-documenting. This is the 'schema-first' design principle.
"""

import uuid
from datetime import datetime
from enum import Enum
from typing import Any

from pydantic import BaseModel, Field, field_validator


class TaskStatus(str, Enum):
    """
    Enumerated task states following a finite state machine model.
    Using str + Enum means values serialize to JSON as plain strings,
    which is critical for REST API compatibility.
    """
    PENDING   = "pending"
    RUNNING   = "running"
    COMPLETED = "completed"
    FAILED    = "failed"
    CANCELLED = "cancelled"


class AgentRole(str, Enum):
    """Defines the distinct agent personas in our multi-agent system."""
    ORCHESTRATOR = "orchestrator"
    RESEARCHER   = "researcher"
    WRITER       = "writer"
    REVIEWER     = "reviewer"


class TaskPriority(str, Enum):
    LOW    = "low"
    MEDIUM = "medium"
    HIGH   = "high"


# ─────────────────────────────────────────────────────────────────────────────
# REQUEST MODELS (Client → API)
# ─────────────────────────────────────────────────────────────────────────────

class CreateTaskRequest(BaseModel):
    """
    Incoming task specification from the user.

    Design decision: We accept a 'goal' in plain language. The orchestrator
    is responsible for decomposing this goal into sub-tasks — the user
    should not need to know about internal agent roles.
    """
    goal: str = Field(
        ...,
        min_length=10,
        max_length=2000,
        description="The high-level objective for the agent team to accomplish",
        examples=["Research the competitive landscape of Anthropic and write a detailed report"]
    )
    context: str | None = Field(
        default=None,
        description="Optional background context to prime the agents",
        max_length=5000,
    )
    priority: TaskPriority = Field(
        default=TaskPriority.MEDIUM,
        description="Task priority (affects queue ordering)"
    )
    config_overrides: dict[str, Any] = Field(
        default_factory=dict,
        description="Per-task overrides for agent settings (e.g., max_iterations)"
    )

    @field_validator("goal")
    @classmethod
    def goal_must_be_meaningful(cls, v: str) -> str:
        """Reject trivially short or meaningless goals."""
        cleaned = v.strip()
        if len(cleaned.split()) < 3:
            raise ValueError("Goal must contain at least 3 words to be actionable.")
        return cleaned


# ─────────────────────────────────────────────────────────────────────────────
# INTERNAL / STATE MODELS (Orchestrator ↔ Agents)
# ─────────────────────────────────────────────────────────────────────────────

class AgentMessage(BaseModel):
    """
    Represents a single message in the multi-agent communication log.
    Stored in the graph state so every agent has full conversation history.
    """
    agent_role: AgentRole
    content: str
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    metadata: dict[str, Any] = Field(default_factory=dict)


class AgentResult(BaseModel):
    """Captures structured output from an individual agent's execution."""
    agent_role: AgentRole
    output: str
    sources: list[str] = Field(default_factory=list)
    quality_score: float | None = None   # 0.0–1.0, set by the Reviewer agent
    execution_time_ms: int = 0
    token_usage: dict[str, int] = Field(default_factory=dict)


# ─────────────────────────────────────────────────────────────────────────────
# RESPONSE MODELS (API → Client)
# ─────────────────────────────────────────────────────────────────────────────

class TaskResponse(BaseModel):
    """Full task object returned to the client."""
    task_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    goal: str
    status: TaskStatus = TaskStatus.PENDING
    priority: TaskPriority
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)
    started_at: datetime | None = None
    completed_at: datetime | None = None

    # Agent outputs
    messages: list[AgentMessage] = Field(default_factory=list)
    agent_results: list[AgentResult] = Field(default_factory=list)
    final_output: str | None = None
    error_message: str | None = None

    # Telemetry
    total_tokens_used: int = 0
    execution_time_seconds: float = 0.0


class TaskSummaryResponse(BaseModel):
    """Lightweight version for listing endpoints (avoids returning huge payloads)."""
    task_id: str
    goal: str
    status: TaskStatus
    priority: TaskPriority
    created_at: datetime
    completed_at: datetime | None = None


class HealthResponse(BaseModel):
    """Health check response model for load balancer probes."""
    status: str = "healthy"
    version: str
    environment: str
    services: dict[str, str] = Field(default_factory=dict)
