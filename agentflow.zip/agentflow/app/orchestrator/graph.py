"""
graph.py — LangGraph Multi-Agent Orchestrator

THIS IS THE HEART OF THE SYSTEM.

WHY LANGGRAPH OVER PLAIN LANGCHAIN:
    LangChain's LCEL (chains) is fundamentally linear: A → B → C.
    Real-world agent workflows need:
      • Cycles (Writer → Reviewer → Writer if quality fails)
      • Conditional branching (route based on Reviewer's decision)
      • Shared persistent state across all steps
      • Human-in-the-loop interrupts at any node

    LangGraph provides all of this as a first-class stateful graph.
    It's what companies like Elastic, Replit, and LinkedIn use in prod.

GRAPH TOPOLOGY:
    ┌─────────────┐
    │    START    │
    └──────┬──────┘
           │
    ┌──────▼──────────┐
    │   RESEARCHER    │  ← Web search + memory retrieval
    └──────┬──────────┘
           │
    ┌──────▼──────────┐
    │     WRITER      │  ← Drafts document from research
    └──────┬──────────┘
           │
    ┌──────▼──────────┐
    │    REVIEWER     │  ← Scores quality (0.0 – 1.0)
    └──────┬──────────┘
           │
    ┌──────▼─────────────────────────────┐
    │       CONDITIONAL ROUTER           │
    │  score ≥ 0.75?  ─YES─→  END        │
    │                 ─NO──→  WRITER     │  ← Revision cycle
    └────────────────────────────────────┘

    Max 2 revision cycles (controlled by revision_count guard)
"""

import json
import logging
from datetime import datetime
from typing import Any

from langgraph.graph import END, START, StateGraph
from langgraph.checkpoint.memory import MemorySaver

from app.agents.researcher import ResearcherAgent
from app.agents.writer import WriterAgent
from app.agents.reviewer import ReviewerAgent
from app.config.settings import get_settings
from app.memory.vector_store import VectorMemory, get_vector_memory
from app.models.task import AgentMessage, AgentResult, AgentRole
from app.orchestrator.state import AgentFlowState

logger = logging.getLogger(__name__)
settings = get_settings()


# ─────────────────────────────────────────────────────────────────────────────
# NODE FUNCTIONS
# Each node is an async function: (state) → partial state update dict
# LangGraph merges these partial updates into the canonical state.
# ─────────────────────────────────────────────────────────────────────────────

async def researcher_node(state: AgentFlowState) -> dict[str, Any]:
    """
    Node 1: Research Agent execution.

    Reads:  goal, context, retrieved_memory
    Writes: research_output, messages, agent_results
    """
    logger.info("[GRAPH] Entering researcher_node: task_id=%s", state.get("task_id"))

    memory = get_vector_memory()
    agent = ResearcherAgent(memory=memory)

    result: AgentResult = await agent.execute(
        task_goal=state["goal"],
        context={
            "task_id": state.get("task_id", ""),
            "context": state.get("context"),
            "retrieved_memory": state.get("retrieved_memory", []),
        },
    )

    message = AgentMessage(
        agent_role=AgentRole.RESEARCHER,
        content=f"Research completed. Found {len(result.sources)} sources. "
                f"Output length: {len(result.output)} chars.",
    )

    return {
        "research_output": result.output,
        "messages": [message],
        "agent_results": [result],
        "total_tokens_used": (
            state.get("total_tokens_used", 0) +
            result.token_usage.get("total_tokens", 0)
        ),
    }


async def writer_node(state: AgentFlowState) -> dict[str, Any]:
    """
    Node 2: Writer Agent execution.

    Reads:  goal, research_output, draft_output (on revision), reviewer_feedback
    Writes: draft_output, messages, agent_results
    """
    revision = state.get("revision_count", 0)
    logger.info(
        "[GRAPH] Entering writer_node: task_id=%s, revision=%d",
        state.get("task_id"), revision,
    )

    agent = WriterAgent()

    result: AgentResult = await agent.execute(
        task_goal=state["goal"],
        context={
            "research_output": state.get("research_output", ""),
            "draft_output": state.get("draft_output", ""),          # Previous draft on revision
            "reviewer_feedback": state.get("reviewer_feedback", ""), # Feedback on revision
        },
    )

    action = "revised draft" if revision > 0 else "initial draft"
    message = AgentMessage(
        agent_role=AgentRole.WRITER,
        content=f"Writer produced {action} (revision #{revision}). "
                f"Document length: {len(result.output)} chars.",
    )

    return {
        "draft_output": result.output,
        "messages": [message],
        "agent_results": [result],
        "total_tokens_used": (
            state.get("total_tokens_used", 0) +
            result.token_usage.get("total_tokens", 0)
        ),
    }


async def reviewer_node(state: AgentFlowState) -> dict[str, Any]:
    """
    Node 3: Reviewer Agent execution.

    Reads:  goal, draft_output, research_output, revision_count
    Writes: reviewer_scorecard, reviewer_feedback, messages, agent_results
    """
    logger.info("[GRAPH] Entering reviewer_node: task_id=%s", state.get("task_id"))

    agent = ReviewerAgent()

    result: AgentResult = await agent.execute(
        task_goal=state["goal"],
        context={
            "draft_output": state.get("draft_output", ""),
            "research_output": state.get("research_output", ""),
            "revision_count": state.get("revision_count", 0),
        },
    )

    # Parse the scorecard JSON from the Reviewer's output
    try:
        scorecard = json.loads(result.output)
    except json.JSONDecodeError:
        scorecard = {"decision": "APPROVED", "overall_score": 0.6, "feedback_for_writer": ""}

    decision = scorecard.get("decision", "APPROVED")
    score = scorecard.get("overall_score", 0.0)

    message = AgentMessage(
        agent_role=AgentRole.REVIEWER,
        content=f"Review complete. Decision: {decision}. Score: {score:.2f}/1.0. "
                f"Required changes: {len(scorecard.get('required_changes', []))}",
        metadata={"score": score, "decision": decision},
    )

    # If approved, set the final output
    final_output = state.get("draft_output", "") if decision == "APPROVED" else None

    return {
        "reviewer_scorecard": scorecard,
        "reviewer_feedback": scorecard.get("feedback_for_writer", ""),
        "final_output": final_output,
        "revision_count": state.get("revision_count", 0) + 1,
        "messages": [message],
        "agent_results": [result],
        "total_tokens_used": (
            state.get("total_tokens_used", 0) +
            result.token_usage.get("total_tokens", 0)
        ),
    }


# ─────────────────────────────────────────────────────────────────────────────
# CONDITIONAL EDGE — The Routing Logic
# This function determines which node to go to AFTER the Reviewer runs.
# ─────────────────────────────────────────────────────────────────────────────

def route_after_review(state: AgentFlowState) -> str:
    """
    Conditional edge function: decides next node after Reviewer.

    WHY THIS PATTERN:
        LangGraph conditional edges are pure functions — they take state
        and return a string node name. This clean separation of routing
        logic from execution logic makes the graph easy to test and reason about.

    Returns:
        "writer" → trigger a revision cycle
        "end"    → pipeline complete, send output to user
    """
    scorecard = state.get("reviewer_scorecard", {})
    decision = scorecard.get("decision", "APPROVED")
    revision_count = state.get("revision_count", 0)

    # Hard limit: max 2 revision cycles to prevent infinite loops
    if revision_count >= 3:
        logger.warning(
            "[GRAPH] Max revisions reached (%d). Force-approving output.",
            revision_count,
        )
        return "end"

    if decision == "REVISION_REQUIRED":
        logger.info(
            "[GRAPH] Reviewer requested revision #%d. Routing back to Writer.",
            revision_count,
        )
        return "writer"

    logger.info("[GRAPH] Reviewer approved output. Routing to END.")
    return "end"


# ─────────────────────────────────────────────────────────────────────────────
# GRAPH BUILDER
# ─────────────────────────────────────────────────────────────────────────────

def build_agent_graph() -> StateGraph:
    """
    Constructs and compiles the LangGraph multi-agent workflow.

    WHY COMPILE ONCE, RUN MANY:
        Compilation validates the graph structure (no orphan nodes,
        valid edge definitions) at startup. The compiled graph is
        then reused for every task — no rebuild overhead per request.

    Returns:
        A compiled LangGraph StateGraph ready to invoke.
    """
    # ── Initialize the graph with our typed state schema ──────────────────
    graph = StateGraph(AgentFlowState)

    # ── Register Nodes ────────────────────────────────────────────────────
    graph.add_node("researcher", researcher_node)
    graph.add_node("writer", writer_node)
    graph.add_node("reviewer", reviewer_node)

    # ── Define Edges (the topology) ───────────────────────────────────────
    graph.add_edge(START, "researcher")       # Entry point
    graph.add_edge("researcher", "writer")    # Always: Research → Write
    graph.add_edge("writer", "reviewer")      # Always: Write → Review

    # Conditional: after Review, either END or loop back to Writer
    graph.add_conditional_edges(
        "reviewer",
        route_after_review,
        {
            "writer": "writer",  # Revision needed
            "end": END,          # Quality approved
        },
    )

    # ── Checkpointing (enables time-travel debugging) ─────────────────────
    # WHY MEMORYSAVER: Stores intermediate state after each node.
    # In production, swap MemorySaver for AsyncRedisSaver for persistence.
    checkpointer = MemorySaver()

    compiled = graph.compile(
        checkpointer=checkpointer,
        interrupt_before=["writer"] if settings.ENABLE_HUMAN_IN_LOOP else [],
    )

    logger.info("AgentFlow graph compiled successfully. Human-in-loop: %s", settings.ENABLE_HUMAN_IN_LOOP)
    return compiled


# ─────────────────────────────────────────────────────────────────────────────
# ORCHESTRATOR CLASS
# ─────────────────────────────────────────────────────────────────────────────

class AgentOrchestrator:
    """
    High-level interface for running the multi-agent pipeline.

    This class wraps the LangGraph and exposes a simple .run() method,
    hiding graph internals from the API layer. This is the Facade pattern —
    complex subsystems presented as a simple interface.
    """

    def __init__(self):
        self._graph = build_agent_graph()
        logger.info("AgentOrchestrator initialized")

    async def run(
        self,
        task_id: str,
        goal: str,
        context: str | None = None,
    ) -> AgentFlowState:
        """
        Executes the full multi-agent pipeline for a given task.

        Args:
            task_id: Unique task identifier (used as graph thread ID)
            goal:    The user's high-level objective
            context: Optional background context

        Returns:
            The final AgentFlowState after pipeline completion
        """
        initial_state: AgentFlowState = {
            "task_id": task_id,
            "goal": goal,
            "context": context,
            "messages": [],
            "agent_results": [],
            "research_output": "",
            "draft_output": "",
            "reviewer_scorecard": {},
            "reviewer_feedback": "",
            "revision_count": 0,
            "final_output": None,
            "retrieved_memory": [],
            "status": "running",
            "error": None,
            "started_at": datetime.utcnow(),
            "completed_at": None,
            "total_tokens_used": 0,
        }

        # WHY thread_id = task_id:
        #   LangGraph uses thread_id for checkpointing. By using the task_id,
        #   every task gets its own isolated checkpoint history.
        #   This enables resuming interrupted tasks and time-travel debugging.
        config = {"configurable": {"thread_id": task_id}}

        try:
            logger.info("[ORCHESTRATOR] Starting pipeline: task_id=%s", task_id)
            final_state = await self._graph.ainvoke(initial_state, config=config)
            final_state["status"] = "completed"
            final_state["completed_at"] = datetime.utcnow()
            logger.info("[ORCHESTRATOR] Pipeline completed: task_id=%s", task_id)
            return final_state

        except Exception as exc:
            logger.error(
                "[ORCHESTRATOR] Pipeline failed: task_id=%s, error=%s",
                task_id, exc, exc_info=True,
            )
            initial_state["status"] = "failed"
            initial_state["error"] = str(exc)
            initial_state["completed_at"] = datetime.utcnow()
            return initial_state


# Module-level singleton
_orchestrator: AgentOrchestrator | None = None


def get_orchestrator() -> AgentOrchestrator:
    """Returns the shared AgentOrchestrator instance."""
    global _orchestrator
    if _orchestrator is None:
        _orchestrator = AgentOrchestrator()
    return _orchestrator
