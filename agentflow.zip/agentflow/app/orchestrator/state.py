"""
state.py — LangGraph Graph State Definition

WHY A TYPED STATE OBJECT:
    LangGraph is built around the concept of a 'state graph' — a directed
    graph where every node (agent) reads from and writes to a shared state.
    Defining this state as a TypedDict gives us:

    1. Type safety: mypy/pyright can catch state key errors at development
       time, not at 2 AM when the prod pipeline silently fails.
    2. Auto-documentation: The type hints make the data flow self-evident
       to anyone reading the codebase — a key interview signal.
    3. LangGraph compatibility: LangGraph's StateGraph requires this exact
       pattern. We follow the framework's idiom rather than fighting it.

REDUCER PATTERN (Annotated with operator.add):
    LangGraph supports 'reducers' — functions that merge new state values
    with existing ones instead of overwriting. Using operator.add on lists
    means agent messages ACCUMULATE across the graph rather than being
    replaced. This gives us a full, immutable audit log of every agent action.
"""

import operator
from datetime import datetime
from typing import Annotated, Any

from typing_extensions import TypedDict

from app.models.task import AgentMessage, AgentResult


class AgentFlowState(TypedDict, total=False):
    """
    The single shared state object that flows through the LangGraph.

    Every node (agent) receives this full state and returns a partial
    update. LangGraph merges the update into the canonical state object.

    Fields:
        task_id:           Unique identifier for the current task
        goal:              The original user goal (immutable after creation)
        context:           Optional background context from the user

        messages:          Full audit log of all agent messages (append-only)
        agent_results:     Structured results from each agent (append-only)

        research_output:   Latest research synthesis from ResearcherAgent
        draft_output:      Latest document draft from WriterAgent
        reviewer_scorecard: Latest quality evaluation from ReviewerAgent
        reviewer_feedback: Specific feedback text for the next Writer iteration

        revision_count:    Number of write→review cycles (prevents infinite loops)
        final_output:      The approved final document (set when Reviewer approves)
        retrieved_memory:  Semantic memory chunks retrieved for this task

        status:            Current pipeline status
        error:             Error message if pipeline fails
        started_at:        Pipeline start timestamp
        completed_at:      Pipeline completion timestamp
    """

    # ── Identity ──────────────────────────────────────────────────────────
    task_id: str
    goal: str
    context: str | None

    # ── Communication Log (append-only via operator.add reducer) ─────────
    # WHY ANNOTATED: This tells LangGraph to USE operator.add to merge
    # new messages INTO the existing list, not replace it.
    messages: Annotated[list[AgentMessage], operator.add]
    agent_results: Annotated[list[AgentResult], operator.add]

    # ── Agent Outputs ─────────────────────────────────────────────────────
    research_output: str
    draft_output: str
    reviewer_scorecard: dict[str, Any]
    reviewer_feedback: str

    # ── Control Flow ──────────────────────────────────────────────────────
    revision_count: int
    final_output: str | None

    # ── Memory ────────────────────────────────────────────────────────────
    retrieved_memory: list[dict[str, Any]]

    # ── Telemetry ─────────────────────────────────────────────────────────
    status: str
    error: str | None
    started_at: datetime | None
    completed_at: datetime | None
    total_tokens_used: int
