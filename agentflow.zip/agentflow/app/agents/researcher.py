"""
researcher.py — The Researcher Agent

ROLE IN THE SYSTEM:
    The Researcher is the first agent to run. Its job is information gathering.
    It uses web search tools to find factual, up-to-date information and
    then synthesizes it into structured research notes for the Writer.

DESIGN CHOICES:
    • Uses ReAct (Reasoning + Acting) prompting pattern: the agent reasons
      about what to search, executes the tool, observes results, then
      decides whether to search again or conclude. This is the foundation
      of modern agentic behavior.
    • Tool-augmented: Unlike a plain LLM call, this agent can interact with
      the real world via Tavily Search API.
    • Temperature set to 0.0: Research should be factual and deterministic,
      not creative.
"""

import logging
from typing import Any

from langchain.agents import AgentExecutor, create_react_agent
from langchain_core.prompts import PromptTemplate
from langchain_community.tools.tavily_search import TavilySearchResults

from app.agents.base_agent import BaseAgent
from app.config.settings import get_settings
from app.models.task import AgentResult, AgentRole
from app.memory.vector_store import VectorMemory

logger = logging.getLogger(__name__)
settings = get_settings()

RESEARCHER_SYSTEM_PROMPT = """You are an elite Research Analyst AI. Your mission is to gather 
comprehensive, accurate, and well-sourced information to fulfill the given research goal.

## Your Capabilities
- You can search the web using the search tool to find current information
- You synthesize multiple sources into coherent research notes
- You always cite your sources by including URLs

## Your Output Standard
- Be factual and objective — no opinions or speculation
- Organize findings into clear sections
- Include key statistics, dates, and named entities
- Flag any conflicting information you find

## Reasoning Process (ReAct)
You MUST think step-by-step:
1. THOUGHT: What do I need to find? What search query will be most effective?
2. ACTION: Execute the search tool
3. OBSERVATION: What did I find? Is this sufficient or do I need more?
4. Repeat until you have comprehensive coverage, then write your final notes.

Available tools: {tools}
Tool names: {tool_names}

{agent_scratchpad}
"""


class ResearcherAgent(BaseAgent):
    """
    The Researcher Agent — information gatherer and synthesizer.

    Uses a ReAct agent executor backed by Tavily web search,
    writing structured research notes that the Writer will use.
    """

    def __init__(self, memory: VectorMemory):
        super().__init__(
            role=AgentRole.RESEARCHER,
            system_prompt=RESEARCHER_SYSTEM_PROMPT,
            temperature=0.0,   # Factual tasks → maximum determinism
        )
        self.memory = memory
        self._tools = self._build_tools()

    def _build_tools(self) -> list:
        """
        Constructs the tool list for this agent.

        WHY TAVILY OVER SERP/GOOGLE:
            Tavily is built specifically for AI agents — it returns
            clean, pre-processed content without HTML noise, handles
            pagination automatically, and provides relevance scores.
            This reduces prompt token waste significantly.
        """
        tools = []

        if settings.TAVILY_API_KEY:
            tools.append(
                TavilySearchResults(
                    max_results=settings.MAX_RESEARCH_RESULTS,
                    search_depth="advanced",   # Deep search, not just snippets
                    include_answer=True,
                    include_raw_content=False,
                    tavily_api_key=settings.TAVILY_API_KEY,
                )
            )
            logger.info("Tavily search tool registered for ResearcherAgent")
        else:
            logger.warning(
                "TAVILY_API_KEY not set — ResearcherAgent will operate without web search. "
                "Set this in .env for production use."
            )

        return tools

    async def execute(
        self,
        task_goal: str,
        context: dict[str, Any],
    ) -> AgentResult:
        """
        Runs the research phase: search → synthesize → store in memory.

        Flow:
            1. Query vector memory for any relevant prior research
            2. Run ReAct agent with web search tool
            3. Persist findings to vector store for future tasks
            4. Return structured AgentResult
        """
        import time
        start = time.perf_counter()

        # ── Step 1: Recall relevant memory ────────────────────────────────
        recalled = []
        try:
            recalled = self.memory.retrieve(
                query=task_goal,
                k=3,
                filter_metadata=None,   # Search across all tasks (global knowledge)
            )
            logger.info("Recalled %d memory chunks for ResearcherAgent", len(recalled))
        except Exception as exc:
            logger.warning("Memory retrieval failed (non-fatal): %s", exc)

        # ── Step 2: Build enriched research query ─────────────────────────
        context_block = self._build_context_prompt({**context, "retrieved_memory": recalled})

        research_prompt = f"""
# Research Goal
{task_goal}

{context_block}

## Instructions
Using the search tool, research the above goal thoroughly. 
Search for multiple angles and perspectives. After gathering sufficient information,
write a comprehensive Research Report with the following sections:
- **Executive Summary** (3-5 sentences)
- **Key Findings** (bulleted, with sources)
- **Supporting Data & Statistics**
- **Notable Players / Companies / People**
- **Potential Gaps or Limitations in Available Data**

Begin your research now.
"""

        # ── Step 3: Execute ReAct agent (if tools available) ──────────────
        research_output = ""
        sources = []
        token_usage = {}

        if self._tools:
            try:
                prompt_template = PromptTemplate(
                    input_variables=["input", "agent_scratchpad", "tools", "tool_names"],
                    template=RESEARCHER_SYSTEM_PROMPT + "\n\nTask: {input}",
                )

                agent = create_react_agent(
                    llm=self.llm,
                    tools=self._tools,
                    prompt=prompt_template,
                )

                executor = AgentExecutor(
                    agent=agent,
                    tools=self._tools,
                    max_iterations=settings.MAX_AGENT_ITERATIONS,
                    verbose=settings.DEBUG,
                    handle_parsing_errors=True,  # Gracefully handle malformed LLM outputs
                    return_intermediate_steps=True,
                )

                result = await executor.ainvoke({"input": research_prompt})
                research_output = result.get("output", "")

                # Extract URLs from intermediate steps
                for step in result.get("intermediate_steps", []):
                    if isinstance(step[1], list):
                        for item in step[1]:
                            if isinstance(item, dict) and "url" in item:
                                sources.append(item["url"])

            except Exception as exc:
                logger.error("ReAct agent execution failed: %s", exc, exc_info=True)
                # Fallback: direct LLM call without tools
                research_output, token_usage = await self._invoke_llm(research_prompt)
        else:
            # No tools — pure LLM reasoning
            research_output, token_usage = await self._invoke_llm(research_prompt)

        # ── Step 4: Persist to vector memory ──────────────────────────────
        if research_output:
            try:
                task_id = context.get("task_id", "unknown")
                # Chunk the output for more granular retrieval
                chunks = self._chunk_text(research_output, chunk_size=500)
                self.memory.store(
                    texts=chunks,
                    metadatas=[
                        {
                            "task_id": task_id,
                            "agent_role": self.role.value,
                            "goal": task_goal[:200],
                        }
                        for _ in chunks
                    ],
                )
                logger.info("Stored %d research chunks in vector memory", len(chunks))
            except Exception as exc:
                logger.warning("Memory storage failed (non-fatal): %s", exc)

        elapsed_ms = int((time.perf_counter() - start) * 1000)

        return AgentResult(
            agent_role=self.role,
            output=research_output or "Research could not be completed.",
            sources=list(set(sources)),  # Deduplicate URLs
            execution_time_ms=elapsed_ms,
            token_usage=token_usage,
        )

    @staticmethod
    def _chunk_text(text: str, chunk_size: int = 500) -> list[str]:
        """
        Splits long text into overlapping chunks for vector storage.

        WHY CHUNKING:
            Vector embeddings work best on focused passages (100–500 tokens).
            Embedding an entire 3000-word report as one vector loses granularity —
            retrieval becomes 'all-or-nothing.' Chunking allows precise recall
            of specific facts, not just the whole document.
        """
        words = text.split()
        chunks = []
        step = chunk_size - 50  # 50-word overlap for context continuity

        for i in range(0, len(words), step):
            chunk = " ".join(words[i : i + chunk_size])
            if chunk.strip():
                chunks.append(chunk)

        return chunks if chunks else [text]
