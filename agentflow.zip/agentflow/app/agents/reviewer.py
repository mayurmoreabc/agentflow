"""
reviewer.py — The Reviewer Agent

ROLE IN THE SYSTEM:
    The Reviewer is the quality gate. It evaluates the Writer's draft against
    the original goal and the research notes, scores it on multiple dimensions,
    and decides whether the output is acceptable or needs revision.

    This creates a feedback loop (Researcher → Writer → Reviewer → Writer → Reviewer)
    that dramatically improves output quality — mimicking the peer review process
    used in high-stakes writing (scientific papers, legal briefs, investment memos).

DESIGN CHOICES:
    • Temperature 0.0: Evaluation must be consistent and objective. Any
      creativity in scoring would make results non-reproducible.
    • Structured JSON output: The Reviewer produces a machine-parseable
      score card. This is critical for the orchestrator to decide whether
      to trigger a revision cycle — a pure text verdict can't be parsed
      reliably.
    • Binary pass/fail + score: Using both gives flexibility. The
      orchestrator can use pass/fail for the revision decision,
      while the score is returned to the user for transparency.

AGENTIC PATTERN — Self-Reflection Loop:
    Having the system evaluate its own output is called a 'self-reflection'
    or 'critic' pattern. It's one of the most powerful techniques in
    modern agentic AI (used in AlphaCode, Reflexion paper, etc.)
"""

import json
import logging
import re
import time
from typing import Any

from app.agents.base_agent import BaseAgent
from app.config.settings import get_settings
from app.models.task import AgentResult, AgentRole

logger = logging.getLogger(__name__)
settings = get_settings()


REVIEWER_SYSTEM_PROMPT = """You are an elite Quality Assurance Reviewer AI. Your role is to 
critically evaluate documents against their research sources and the original user goal.

## Evaluation Philosophy
You are a tough but fair reviewer. Your standards are high because the output
will be used by professionals who depend on its accuracy. Do not give passing
grades to mediocre work.

## Scoring Dimensions (each 0.0 to 1.0)
1. **accuracy**: Are all claims traceable to the research notes?
2. **completeness**: Does the document fully address the original goal?
3. **clarity**: Is the writing clear, well-organized, and free of ambiguity?
4. **structure**: Does it have proper sections, logical flow, appropriate length?
5. **actionability**: Are the recommendations concrete and useful?

## Decision Rule
- Overall score = weighted average of all dimensions
- Score ≥ 0.75 → APPROVED (send to user)
- Score < 0.75 → REVISION_REQUIRED (send back to Writer with specific feedback)

## Your Output Format
You MUST respond with valid JSON only (no markdown code blocks, no preamble):
{
  "scores": {
    "accuracy": 0.0-1.0,
    "completeness": 0.0-1.0,
    "clarity": 0.0-1.0,
    "structure": 0.0-1.0,
    "actionability": 0.0-1.0
  },
  "overall_score": 0.0-1.0,
  "decision": "APPROVED" or "REVISION_REQUIRED",
  "strengths": ["...", "..."],
  "required_changes": ["...", "..."],
  "feedback_for_writer": "Detailed, specific, actionable feedback paragraph"
}
"""


class ReviewerAgent(BaseAgent):
    """
    The Reviewer Agent — evaluates draft quality and triggers revision loops.

    Produces a structured evaluation scorecard that the orchestrator uses
    to decide whether to approve the output or cycle back to the Writer.
    """

    # Weights for the overall score calculation
    # WHY WEIGHTED: Accuracy and completeness matter more than style
    SCORE_WEIGHTS = {
        "accuracy": 0.30,
        "completeness": 0.25,
        "clarity": 0.20,
        "structure": 0.15,
        "actionability": 0.10,
    }

    APPROVAL_THRESHOLD = 0.75

    def __init__(self):
        super().__init__(
            role=AgentRole.REVIEWER,
            system_prompt=REVIEWER_SYSTEM_PROMPT,
            temperature=0.0,  # Evaluation MUST be deterministic — no variance
        )

    async def execute(
        self,
        task_goal: str,
        context: dict[str, Any],
    ) -> AgentResult:
        """
        Evaluates the Writer's draft and produces a scorecard.

        Returns an AgentResult where:
          - output: The raw JSON scorecard string
          - quality_score: The parsed overall score (0.0–1.0)
          - metadata in context: decision + feedback_for_writer
        """
        start = time.perf_counter()

        draft = context.get("draft_output", "")
        research = context.get("research_output", "")
        revision_count = context.get("revision_count", 0)

        if not draft:
            logger.error("Reviewer received empty draft")
            return self._create_error_result("No draft provided to review")

        evaluation_prompt = self._build_evaluation_prompt(
            task_goal=task_goal,
            draft=draft,
            research=research,
            revision_count=revision_count,
        )

        raw_output, token_usage = await self._invoke_llm(evaluation_prompt)

        # ── Parse the structured JSON response ────────────────────────────
        scorecard = self._parse_scorecard(raw_output, revision_count)

        elapsed_ms = int((time.perf_counter() - start) * 1000)

        logger.info(
            "ReviewerAgent completed: decision=%s, score=%.2f, elapsed_ms=%d",
            scorecard.get("decision"),
            scorecard.get("overall_score", 0.0),
            elapsed_ms,
        )

        return AgentResult(
            agent_role=self.role,
            output=json.dumps(scorecard, indent=2),
            quality_score=scorecard.get("overall_score", 0.0),
            execution_time_ms=elapsed_ms,
            token_usage=token_usage,
        )

    def _build_evaluation_prompt(
        self,
        task_goal: str,
        draft: str,
        research: str,
        revision_count: int,
    ) -> str:
        """Constructs the full evaluation brief for the Reviewer."""

        # After revision, be slightly more lenient (convergence protection)
        threshold_note = ""
        if revision_count > 0:
            threshold_note = f"""
**Note:** This is revision #{revision_count}. The document has been revised based on prior feedback.
Weight improvements from feedback heavily in your evaluation.
"""

        return f"""
## Review Assignment
{threshold_note}

### Original User Goal
{task_goal}

### Research Notes (Source of Truth for Accuracy)
{research[:3000] if research else "No research notes available."}
{"[Research truncated for brevity]" if len(research) > 3000 else ""}

### Document to Review
{draft}

---
Evaluate the document above against the criteria in your system prompt.
Output ONLY valid JSON — no markdown, no commentary outside the JSON structure.
"""

    def _parse_scorecard(
        self,
        raw_output: str,
        revision_count: int,
    ) -> dict[str, Any]:
        """
        Parses the LLM's JSON response with robust fallback handling.

        WHY ROBUST PARSING:
            LLMs sometimes wrap JSON in markdown code blocks (```json ... ```)
            despite instructions not to. Production systems need graceful
            handling of these formatting quirks — a rigid JSON parser
            would crash the entire pipeline on a minor formatting issue.
        """
        # Strip markdown code fences if present
        cleaned = re.sub(r"```(?:json)?\s*|\s*```", "", raw_output).strip()

        try:
            scorecard = json.loads(cleaned)

            # Recalculate overall score using our defined weights
            # (prevents the LLM from arbitrarily inflating the score)
            scores = scorecard.get("scores", {})
            weighted_score = sum(
                scores.get(dim, 0.5) * weight
                for dim, weight in self.SCORE_WEIGHTS.items()
            )
            scorecard["overall_score"] = round(weighted_score, 3)

            # After 2+ revisions, automatically approve to prevent infinite loops
            if revision_count >= 2 and scorecard.get("overall_score", 0) > 0.6:
                scorecard["decision"] = "APPROVED"
                scorecard["auto_approved"] = True
                logger.info("Auto-approved after %d revisions (convergence protection)", revision_count)

            return scorecard

        except json.JSONDecodeError as exc:
            logger.error("Failed to parse Reviewer JSON output: %s\nRaw: %s", exc, raw_output[:500])

            # Fallback scorecard — safe default that doesn't block the pipeline
            return {
                "scores": {dim: 0.6 for dim in self.SCORE_WEIGHTS},
                "overall_score": 0.6,
                "decision": "APPROVED" if revision_count >= 1 else "REVISION_REQUIRED",
                "strengths": ["Unable to parse structured review"],
                "required_changes": ["Review parsing failed — using fallback"],
                "feedback_for_writer": raw_output[:1000],  # Pass raw text as feedback
                "parse_error": True,
            }

    def _create_error_result(self, message: str) -> AgentResult:
        """Creates a standardized error AgentResult."""
        error_scorecard = {
            "scores": {dim: 0.0 for dim in self.SCORE_WEIGHTS},
            "overall_score": 0.0,
            "decision": "REVISION_REQUIRED",
            "strengths": [],
            "required_changes": [message],
            "feedback_for_writer": message,
            "error": True,
        }
        return AgentResult(
            agent_role=self.role,
            output=json.dumps(error_scorecard),
            quality_score=0.0,
        )
