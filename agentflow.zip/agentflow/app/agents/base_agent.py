"""
base_agent.py — Abstract Base Class for All Agents

WHY AN ABSTRACT BASE CLASS:
    All agents in our system share common concerns:
      • LLM initialization with consistent settings
      • Structured output formatting
      • Token usage tracking for cost observability
      • Error handling and retry logic

    Defining this once in a base class (DRY principle) means specialized
    agents (Researcher, Writer, Reviewer) only implement their unique logic.
    This is the Template Method design pattern applied to AI agents.

    Interviewers look for this — it shows you design for maintainability,
    not just "get it working."
"""

import logging
import time
from abc import ABC, abstractmethod
from typing import Any

from langchain_core.messages import HumanMessage, SystemMessage
from langchain_openai import ChatOpenAI

from app.config.settings import get_settings
from app.models.task import AgentResult, AgentRole

logger = logging.getLogger(__name__)
settings = get_settings()


class BaseAgent(ABC):
    """
    Abstract base class that all specialized agents must inherit from.

    Enforces a consistent interface while allowing complete flexibility
    in each agent's internal reasoning strategy.
    """

    def __init__(
        self,
        role: AgentRole,
        system_prompt: str,
        temperature: float | None = None,
    ):
        """
        Args:
            role:          The agent's designated role in the team
            system_prompt: The agent's persona and behavioral instructions
            temperature:   LLM sampling temperature (lower = more deterministic)
        """
        self.role = role
        self.system_prompt = system_prompt

        # ─────────────────────────────────────────────────────────
        # LLM INITIALIZATION
        # WHY NOT SHARE A SINGLE LLM INSTANCE:
        #   Different agents may need different temperatures.
        #   The Researcher benefits from creativity (higher temp),
        #   while the Reviewer needs strict, deterministic evaluation.
        #   Per-agent LLM instances honor this requirement cleanly.
        # ─────────────────────────────────────────────────────────
        self.llm = ChatOpenAI(
            model=settings.OPENAI_MODEL,
            temperature=temperature if temperature is not None else settings.OPENAI_TEMPERATURE,
            max_tokens=settings.OPENAI_MAX_TOKENS,
            openai_api_key=settings.OPENAI_API_KEY,
        )

        logger.info("Agent initialized: role=%s, model=%s", self.role.value, settings.OPENAI_MODEL)

    @abstractmethod
    async def execute(
        self,
        task_goal: str,
        context: dict[str, Any],
    ) -> AgentResult:
        """
        Core agent logic — must be implemented by each specialized agent.

        Args:
            task_goal: The high-level user goal
            context:   Shared state dict from the LangGraph orchestrator
                       (contains prior agent outputs, retrieved memory, etc.)

        Returns:
            AgentResult with the agent's structured output
        """
        ...

    async def _invoke_llm(
        self,
        user_message: str,
        system_override: str | None = None,
    ) -> tuple[str, dict[str, int]]:
        """
        Unified LLM invocation with token tracking.

        WHY CENTRALIZE THIS:
            If we later add retry logic, rate-limit handling, or swap LLM
            providers, we change it in one place — not in every agent.
            This is the Single Responsibility Principle in action.

        Returns:
            Tuple of (response_text, token_usage_dict)
        """
        messages = [
            SystemMessage(content=system_override or self.system_prompt),
            HumanMessage(content=user_message),
        ]

        start_time = time.perf_counter()
        response = await self.llm.ainvoke(messages)
        elapsed_ms = int((time.perf_counter() - start_time) * 1000)

        # Extract token usage from LangChain response metadata
        usage = {}
        if hasattr(response, "usage_metadata") and response.usage_metadata:
            usage = {
                "prompt_tokens": response.usage_metadata.get("input_tokens", 0),
                "completion_tokens": response.usage_metadata.get("output_tokens", 0),
                "total_tokens": response.usage_metadata.get("total_tokens", 0),
            }

        logger.debug(
            "LLM call completed: agent=%s, elapsed_ms=%d, tokens=%s",
            self.role.value, elapsed_ms, usage
        )

        return str(response.content), usage

    def _build_context_prompt(self, context: dict[str, Any]) -> str:
        """
        Serializes the shared graph state into a human-readable context block.

        WHY: LLMs perform better with well-structured context. Rather than
        dumping raw JSON into the prompt, we format it as a clear document.
        """
        parts = ["## Available Context\n"]

        if context.get("retrieved_memory"):
            parts.append("### Relevant Memory (from previous tasks):")
            for mem in context["retrieved_memory"][:3]:  # Limit to avoid context bloat
                parts.append(f"- {mem['content'][:500]}")
            parts.append("")

        if context.get("research_output"):
            parts.append("### Research Agent Output:")
            parts.append(context["research_output"])
            parts.append("")

        if context.get("draft_output"):
            parts.append("### Writer Agent Draft:")
            parts.append(context["draft_output"])
            parts.append("")

        return "\n".join(parts)
