"""
writer.py — The Writer Agent

ROLE IN THE SYSTEM:
    The Writer receives the Researcher's structured notes and transforms them
    into a polished, professional document. It does NOT do additional research —
    its only job is to write well.

    This separation of concerns (research vs. writing) is a deliberate
    architectural choice inspired by real human workflows. It produces
    significantly higher quality output than asking a single agent to
    "research and write" simultaneously, because the LLM can focus
    entirely on craft rather than splitting attention.

DESIGN CHOICES:
    • Higher temperature (0.3) than Researcher: Writing benefits from
      slightly more creativity and stylistic variation.
    • No external tools: The Writer has everything it needs from context.
      Giving it search tools would distract it from its writing mission.
    • Structured output: Always produces a document with consistent
      heading structure so the Reviewer can evaluate it systematically.
"""

import logging
import time
from typing import Any

from app.agents.base_agent import BaseAgent
from app.config.settings import get_settings
from app.models.task import AgentResult, AgentRole

logger = logging.getLogger(__name__)
settings = get_settings()


WRITER_SYSTEM_PROMPT = """You are an elite Technical Writer AI with expertise in transforming 
complex research into clear, compelling, and professionally structured documents.

## Your Core Responsibilities
1. Transform raw research notes into polished, publication-ready content
2. Maintain factual accuracy — never add information not present in the research
3. Write for a technically sophisticated audience (C-suite, senior engineers, analysts)
4. Produce well-structured Markdown documents

## Writing Standards
- Use active voice and precise language
- Every claim must trace back to the provided research
- Include all relevant statistics and data points
- Structure documents with clear H2/H3 headings
- Conclude with actionable insights or next steps

## What You Do NOT Do
- Conduct additional research (trust the Researcher's notes)
- Fabricate statistics or quotes
- Use filler phrases ("It's important to note that...")
- Exceed the scope defined by the research provided
"""


class WriterAgent(BaseAgent):
    """
    The Writer Agent — transforms research into polished documents.

    Operates purely on context from the Researcher, with no external tools.
    This enforces the single-responsibility principle at the agent level.
    """

    def __init__(self):
        super().__init__(
            role=AgentRole.WRITER,
            system_prompt=WRITER_SYSTEM_PROMPT,
            temperature=0.3,  # Slight creativity for engaging prose, still factual
        )

    async def execute(
        self,
        task_goal: str,
        context: dict[str, Any],
    ) -> AgentResult:
        """
        Transforms research notes into a polished document.

        The Writer's quality is entirely dependent on the Researcher's output.
        If research is poor, the Writer will faithfully write a poor document —
        which is why we have the Reviewer as a quality gate.
        """
        start = time.perf_counter()

        research_output = context.get("research_output", "")

        if not research_output:
            logger.warning("Writer received no research output — will attempt general writing")

        # Build the full writing brief
        writing_prompt = self._build_writing_prompt(task_goal, research_output, context)

        # Direct LLM call — no tools needed for writing
        draft, token_usage = await self._invoke_llm(writing_prompt)

        elapsed_ms = int((time.perf_counter() - start) * 1000)

        logger.info(
            "WriterAgent completed: chars=%d, elapsed_ms=%d",
            len(draft), elapsed_ms
        )

        return AgentResult(
            agent_role=self.role,
            output=draft,
            sources=[],  # Writer doesn't add new sources — inherits from Researcher
            execution_time_ms=elapsed_ms,
            token_usage=token_usage,
        )

    def _build_writing_prompt(
        self,
        task_goal: str,
        research_output: str,
        context: dict[str, Any],
    ) -> str:
        """
        Constructs a detailed, structured brief for the writing task.

        WHY A DETAILED BRIEF:
            LLMs produce dramatically better output with explicit structure
            instructions. Telling it exactly what sections to produce
            (rather than "write something") reduces hallucination and
            improves consistency across runs — critical for production systems.
        """
        reviewer_feedback = context.get("reviewer_feedback", "")
        is_revision = bool(reviewer_feedback)

        if is_revision:
            # ── REVISION MODE: Writer received Reviewer feedback ───────────
            previous_draft = context.get("draft_output", "")
            return f"""
## Revision Task
You previously wrote a draft that was reviewed. Below is the feedback and your previous draft.
Revise the document to address ALL feedback points.

### Original Goal
{task_goal}

### Reviewer's Feedback
{reviewer_feedback}

### Your Previous Draft
{previous_draft}

### Research Notes (reference these for any factual revisions)
{research_output}

## Instructions
Produce a revised, complete document that fully addresses all reviewer feedback.
Output ONLY the revised document in Markdown format.
"""
        else:
            # ── INITIAL DRAFT MODE ─────────────────────────────────────────
            return f"""
## Writing Assignment

### Goal
Transform the following research notes into a comprehensive, professional document.

**Original User Goal:** {task_goal}

### Research Notes
{research_output if research_output else "No research available — write based on general knowledge."}

### Required Document Structure
Produce a complete Markdown document with these sections:

1. **Executive Summary** (150-200 words)
   - Key takeaways a busy executive needs in 60 seconds

2. **Background & Context**
   - Why this topic matters, relevant history

3. **Core Analysis**
   - Deep dive into the primary findings
   - Subsections as appropriate for the content

4. **Data & Evidence**
   - All statistics, metrics, and evidence from the research
   - Present in tables where appropriate

5. **Key Players / Stakeholders**
   - Who are the important entities and their roles?

6. **Strategic Implications**
   - What does this mean for decision-makers?

7. **Recommendations & Next Steps**
   - 3-5 concrete, actionable recommendations

8. **Sources & References**
   - List all sources from the research notes

---
Write the complete document now. Output Markdown only — no preamble or meta-commentary.
"""
