"""
app/__init__.py — FastAPI Application Factory

WHY AN APPLICATION FACTORY:
    Defining the FastAPI app in a factory function (create_app) rather
    than module-level makes the app:
    1. Testable: Tests can call create_app() to get a fresh instance
    2. Flexible: Different configs for dev/test/prod
    3. Import-safe: Avoids circular imports from module-level app instantiation

    This is the standard pattern used by Flask and FastAPI in production codebases.
"""

import logging
import time

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.responses import JSONResponse

from app.api.routes import health, tasks
from app.config.settings import get_settings

settings = get_settings()


def create_app() -> FastAPI:
    """
    Creates and configures the FastAPI application instance.

    Returns:
        Fully configured FastAPI application
    """
    app = FastAPI(
        title="AgentFlow — Enterprise AI Agent Orchestrator",
        description=(
            "Multi-agent AI pipeline powered by LangGraph. "
            "Spawn Researcher → Writer → Reviewer agent teams to accomplish complex goals autonomously."
        ),
        version=settings.APP_VERSION,
        docs_url="/docs",
        redoc_url="/redoc",
        openapi_url="/openapi.json",
    )

    # ── Middleware ────────────────────────────────────────────────────────

    # CORS: Allow all origins in dev; restrict to specific domains in prod
    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.CORS_ORIGINS,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # GZip: Compress responses > 1KB (agent outputs can be large documents)
    app.add_middleware(GZipMiddleware, minimum_size=1000)

    # ── Request Timing Middleware ─────────────────────────────────────────
    @app.middleware("http")
    async def add_timing_header(request: Request, call_next):
        """
        Adds X-Process-Time header to every response.
        WHY: Gives clients and monitoring systems visibility into server-side
        latency without requiring a tracing system.
        """
        start = time.perf_counter()
        response = await call_next(request)
        elapsed = time.perf_counter() - start
        response.headers["X-Process-Time"] = f"{elapsed:.4f}s"
        return response

    # ── Global Exception Handler ──────────────────────────────────────────
    @app.exception_handler(Exception)
    async def global_exception_handler(request: Request, exc: Exception):
        """
        Catches unhandled exceptions and returns structured JSON errors.
        Prevents stack traces from leaking to clients in production.
        """
        logging.getLogger(__name__).error(
            "Unhandled exception: %s %s → %s",
            request.method, request.url.path, exc,
            exc_info=True,
        )
        return JSONResponse(
            status_code=500,
            content={
                "error": "internal_server_error",
                "message": "An unexpected error occurred. Check server logs.",
                "path": str(request.url.path),
            },
        )

    # ── Startup / Shutdown Events ─────────────────────────────────────────
    @app.on_event("startup")
    async def startup_event():
        logging.basicConfig(
            level=getattr(logging, settings.LOG_LEVEL.upper(), logging.INFO),
            format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
        )
        logging.getLogger(__name__).info(
            "AgentFlow v%s starting up in '%s' mode",
            settings.APP_VERSION, settings.APP_ENV,
        )

    @app.on_event("shutdown")
    async def shutdown_event():
        logging.getLogger(__name__).info("AgentFlow shutting down.")

    # ── Register Routers ──────────────────────────────────────────────────
    app.include_router(health.router, prefix=settings.API_PREFIX)
    app.include_router(tasks.router, prefix=settings.API_PREFIX)

    # ── Root redirect ─────────────────────────────────────────────────────
    @app.get("/", include_in_schema=False)
    async def root():
        return {
            "service": "AgentFlow",
            "version": settings.APP_VERSION,
            "docs": "/docs",
            "health": f"{settings.API_PREFIX}/health/live",
        }

    return app
