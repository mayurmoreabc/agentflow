"""
settings.py — Centralized Configuration Management

WHY THIS PATTERN:
    Using Pydantic's BaseSettings gives us a single source of truth for all
    configuration. It automatically reads from environment variables and .env files,
    validates types at startup (fail-fast principle), and prevents runtime errors
    caused by missing config. This is the industry standard for 12-Factor App
    compliance (https://12factor.net/config).
"""

from functools import lru_cache
from typing import Literal
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """
    Application-wide settings, validated at startup.

    Pydantic will raise a ValidationError immediately if a required field
    is missing or has the wrong type — no silent failures in production.
    """

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",  # Ignore any extra env vars not defined here
    )

    # ─────────────────────────────────────────────────────────────
    # APPLICATION
    # ─────────────────────────────────────────────────────────────
    APP_NAME: str = "AgentFlow"
    APP_VERSION: str = "1.0.0"
    APP_ENV: Literal["development", "staging", "production"] = "development"
    DEBUG: bool = False
    LOG_LEVEL: str = "INFO"

    # ─────────────────────────────────────────────────────────────
    # API SERVER
    # ─────────────────────────────────────────────────────────────
    HOST: str = "0.0.0.0"
    PORT: int = 8000
    API_PREFIX: str = "/api/v1"
    CORS_ORIGINS: list[str] = ["*"]

    # ─────────────────────────────────────────────────────────────
    # LLM CONFIGURATION
    # WHY: Abstracting model names into config lets us swap
    #      GPT-4o → Claude → Gemini without touching agent code.
    # ─────────────────────────────────────────────────────────────
    OPENAI_API_KEY: str
    OPENAI_MODEL: str = "gpt-4o"
    OPENAI_TEMPERATURE: float = 0.1   # Low temp → deterministic, factual output
    OPENAI_MAX_TOKENS: int = 4096

    # Optional: Anthropic as a fallback LLM
    ANTHROPIC_API_KEY: str = ""

    # ─────────────────────────────────────────────────────────────
    # MEMORY / VECTOR DATABASE (ChromaDB)
    # WHY ChromaDB: Runs embedded (no server needed in dev), but can
    #               be swapped for Pinecone/Weaviate in production
    #               via the VectorStore abstraction layer.
    # ─────────────────────────────────────────────────────────────
    CHROMA_HOST: str = "chromadb"      # Docker service name
    CHROMA_PORT: int = 8001
    CHROMA_COLLECTION_NAME: str = "agentflow_memory"
    EMBEDDING_MODEL: str = "text-embedding-3-small"

    # ─────────────────────────────────────────────────────────────
    # TOOLS CONFIGURATION
    # ─────────────────────────────────────────────────────────────
    TAVILY_API_KEY: str = ""           # Web search tool
    SERPAPI_KEY: str = ""              # Fallback search

    # ─────────────────────────────────────────────────────────────
    # ORCHESTRATOR SETTINGS
    # ─────────────────────────────────────────────────────────────
    MAX_AGENT_ITERATIONS: int = 10     # Guard against infinite loops
    MAX_RESEARCH_RESULTS: int = 5
    TASK_TIMEOUT_SECONDS: int = 300    # 5-minute hard timeout per task
    ENABLE_HUMAN_IN_LOOP: bool = False # Set True to pause for human approval


@lru_cache
def get_settings() -> Settings:
    """
    Returns a cached singleton Settings instance.

    WHY lru_cache:
        Settings object is expensive to create (reads .env, validates).
        Caching ensures we parse once at cold start, then reuse. This is
        the recommended FastAPI pattern for dependency injection of config.
    """
    return Settings()
