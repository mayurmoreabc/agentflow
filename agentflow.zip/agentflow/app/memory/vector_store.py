"""
vector_store.py — Agent Memory Layer (ChromaDB)

WHY A VECTOR STORE FOR AGENT MEMORY:
    Traditional agents are stateless — each invocation starts with zero context.
    A vector store gives agents semantic long-term memory:
      • They can recall relevant past research without re-running expensive LLM calls
      • Retrieved context is ranked by semantic relevance, not keyword match
      • Supports Retrieval-Augmented Generation (RAG) patterns at every agent step

ARCHITECTURE DECISION — ChromaDB over Pinecone:
    ChromaDB runs embedded with zero external dependencies in development.
    We abstract it behind the VectorMemory interface so production can swap
    to Pinecone/Weaviate by changing one config value. This is the
    Dependency Inversion Principle applied to infrastructure.
"""

import logging
from typing import Any

import chromadb
from chromadb.config import Settings as ChromaSettings
from langchain_openai import OpenAIEmbeddings
from langchain_chroma import Chroma

from app.config.settings import get_settings

logger = logging.getLogger(__name__)
settings = get_settings()


class VectorMemory:
    """
    Abstraction layer over ChromaDB for agent memory persistence.

    Pattern: Repository Pattern — agents interact with this class only,
    never with ChromaDB directly. This keeps infrastructure concerns
    isolated from business logic.
    """

    def __init__(self, collection_name: str | None = None):
        self.collection_name = collection_name or settings.CHROMA_COLLECTION_NAME
        self._client: chromadb.HttpClient | None = None
        self._store: Chroma | None = None
        self._embeddings = OpenAIEmbeddings(
            model=settings.EMBEDDING_MODEL,
            openai_api_key=settings.OPENAI_API_KEY,
        )

    def _get_client(self) -> chromadb.HttpClient:
        """
        Lazy-initializes the ChromaDB HTTP client.

        WHY LAZY INIT:
            We don't want to fail at import time if ChromaDB isn't ready yet.
            Docker containers take time to start — lazy init + retry logic
            gives the DB container time to become healthy before we connect.
        """
        if self._client is None:
            self._client = chromadb.HttpClient(
                host=settings.CHROMA_HOST,
                port=settings.CHROMA_PORT,
                settings=ChromaSettings(anonymized_telemetry=False),
            )
            logger.info(
                "ChromaDB client connected → %s:%d",
                settings.CHROMA_HOST,
                settings.CHROMA_PORT,
            )
        return self._client

    def _get_store(self) -> Chroma:
        """Returns the LangChain Chroma wrapper (includes embedding logic)."""
        if self._store is None:
            self._store = Chroma(
                client=self._get_client(),
                collection_name=self.collection_name,
                embedding_function=self._embeddings,
            )
        return self._store

    def store(
        self,
        texts: list[str],
        metadatas: list[dict[str, Any]] | None = None,
        ids: list[str] | None = None,
    ) -> list[str]:
        """
        Embed and persist a list of text chunks into the vector store.

        Args:
            texts:     Text chunks to embed and store
            metadatas: Optional dicts attached to each chunk (e.g., agent_role, task_id)
            ids:       Optional stable IDs (enables idempotent writes / deduplication)

        Returns:
            List of assigned document IDs
        """
        store = self._get_store()
        stored_ids = store.add_texts(
            texts=texts,
            metadatas=metadatas or [{} for _ in texts],
            ids=ids,
        )
        logger.debug("Stored %d chunks in ChromaDB collection '%s'", len(texts), self.collection_name)
        return stored_ids

    def retrieve(
        self,
        query: str,
        k: int = 5,
        filter_metadata: dict[str, Any] | None = None,
    ) -> list[dict[str, Any]]:
        """
        Semantically retrieve the top-k most relevant memory chunks.

        WHY SIMILARITY SEARCH OVER KEYWORD:
            Agents ask questions in natural language. Semantic search
            finds relevant memory even when exact words don't match —
            critical for robust context retrieval across multi-step tasks.

        Args:
            query:           Natural language query from the agent
            k:               Number of results to return
            filter_metadata: Optional ChromaDB where-filter dict

        Returns:
            List of dicts with 'content', 'metadata', and 'score' keys
        """
        store = self._get_store()
        results = store.similarity_search_with_relevance_scores(
            query=query,
            k=k,
            filter=filter_metadata,
        )
        return [
            {
                "content": doc.page_content,
                "metadata": doc.metadata,
                "score": float(score),
            }
            for doc, score in results
        ]

    def clear_task_memory(self, task_id: str) -> None:
        """
        Delete all memory chunks associated with a specific task.

        WHY: Prevents memory pollution between tasks. Each task starts
        fresh, but can still query global/shared knowledge if needed.
        """
        client = self._get_client()
        collection = client.get_or_create_collection(self.collection_name)
        collection.delete(where={"task_id": task_id})
        logger.info("Cleared memory for task_id=%s", task_id)

    def health_check(self) -> bool:
        """Ping ChromaDB to verify connectivity (used by /health endpoint)."""
        try:
            self._get_client().heartbeat()
            return True
        except Exception as exc:
            logger.error("ChromaDB health check failed: %s", exc)
            return False


# ─────────────────────────────────────────────────────────────────────────────
# MODULE-LEVEL SINGLETON
# WHY: One shared VectorMemory instance prevents connection pool exhaustion.
#      FastAPI's dependency injection system uses this via Depends().
# ─────────────────────────────────────────────────────────────────────────────
_vector_memory: VectorMemory | None = None


def get_vector_memory() -> VectorMemory:
    """FastAPI dependency: returns the shared VectorMemory instance."""
    global _vector_memory
    if _vector_memory is None:
        _vector_memory = VectorMemory()
    return _vector_memory
