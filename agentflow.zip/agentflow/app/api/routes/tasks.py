"""
tasks.py — Task API Routes

WHY FASTAPI:
    FastAPI gives us:
    • Automatic OpenAPI/Swagger docs at /docs (zero extra work)
    • Async-first: perfectly matches our async LangGraph pipeline
    • Pydantic integration: request/response validation is automatic
    • Dependency injection: clean separation of concerns

DESIGN — Background Tasks for Long-Running Pipelines:
    Multi-agent pipelines can take 30–120 seconds. A synchronous POST
    that holds the connection open that long will timeout on most
    infrastructure (load balancers, API gateways default to 60s).

    Solution: Accept the task → immediately return task_id → process async.
    Clients poll GET /tasks/{task_id} for status. This is the standard
    pattern for long-running async jobs in production systems.
"""

import asyncio
import logging
import uuid
from datetime import datetime

from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException, status

from app.config.settings import Settings, get_settings
from app.models.task import (
    CreateTaskRequest,
    TaskResponse,
    TaskStatus,
    TaskSummaryResponse,
    AgentMessage,
)
from app.orchestrator.graph import AgentOrchestrator, get_orchestrator

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/tasks", tags=["Tasks"])

# ─────────────────────────────────────────────────────────────────────────────
# IN-MEMORY TASK STORE
# WHY IN-MEMORY (not Redis/DB):
#   For a portfolio project this is intentional simplicity.
#   In production, swap this dict for a Redis hash store + TTL.
#   The TaskStore abstraction makes that swap trivial.
# ─────────────────────────────────────────────────────────────────────────────
_task_store: dict[str, TaskResponse] = {}


def _get_task_or_404(task_id: str) -> TaskResponse:
    """Retrieve a task or raise 404. Reused across multiple endpoints."""
    task = _task_store.get(task_id)
    if not task:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Task '{task_id}' not found.",
        )
    return task


# ─────────────────────────────────────────────────────────────────────────────
# BACKGROUND PIPELINE RUNNER
# ─────────────────────────────────────────────────────────────────────────────

async def _run_pipeline(
    task_id: str,
    goal: str,
    context: str | None,
    orchestrator: AgentOrchestrator,
    timeout: int,
) -> None:
    """
    Runs the multi-agent pipeline in the background.

    This function is passed to FastAPI's BackgroundTasks — it runs after
    the HTTP response is sent to the client, not during request handling.

    Timeout wrapping prevents runaway tasks from consuming resources
    indefinitely — critical for multi-tenant production deployments.
    """
    task = _task_store[task_id]
    task.status = TaskStatus.RUNNING
    task.started_at = datetime.utcnow()

    try:
        # Wrap with timeout to prevent infinite agent loops
        final_state = await asyncio.wait_for(
            orchestrator.run(task_id=task_id, goal=goal, context=context),
            timeout=timeout,
        )

        # ── Map graph state → TaskResponse ────────────────────────────────
        task.status = TaskStatus.COMPLETED
        task.completed_at = final_state.get("completed_at") or datetime.utcnow()
        task.final_output = final_state.get("final_output") or final_state.get("draft_output")
        task.agent_results = final_state.get("agent_results", [])
        task.messages = final_state.get("messages", [])
        task.total_tokens_used = final_state.get("total_tokens_used", 0)

        if task.started_at and task.completed_at:
            task.execution_time_seconds = (
                task.completed_at - task.started_at
            ).total_seconds()

        logger.info(
            "Pipeline completed: task_id=%s, tokens=%d, time=%.1fs",
            task_id, task.total_tokens_used, task.execution_time_seconds,
        )

    except asyncio.TimeoutError:
        task.status = TaskStatus.FAILED
        task.error_message = f"Pipeline timed out after {timeout} seconds."
        task.completed_at = datetime.utcnow()
        logger.error("Pipeline timed out: task_id=%s", task_id)

    except Exception as exc:
        task.status = TaskStatus.FAILED
        task.error_message = str(exc)
        task.completed_at = datetime.utcnow()
        logger.error("Pipeline failed: task_id=%s, error=%s", task_id, exc, exc_info=True)

    finally:
        task.updated_at = datetime.utcnow()


# ─────────────────────────────────────────────────────────────────────────────
# ENDPOINTS
# ─────────────────────────────────────────────────────────────────────────────

@router.post(
    "/",
    response_model=TaskResponse,
    status_code=status.HTTP_202_ACCEPTED,
    summary="Create and launch a new agent task",
    description=(
        "Accepts a goal, immediately returns a task object with status=pending, "
        "then runs the multi-agent pipeline asynchronously. Poll GET /tasks/{task_id} "
        "for results."
    ),
)
async def create_task(
    request: CreateTaskRequest,
    background_tasks: BackgroundTasks,
    orchestrator: AgentOrchestrator = Depends(get_orchestrator),
    settings: Settings = Depends(get_settings),
) -> TaskResponse:
    """
    POST /api/v1/tasks

    The 202 Accepted response is intentional: the pipeline hasn't run yet.
    We return the task immediately so clients aren't blocked waiting for
    potentially 60+ seconds of agent execution.
    """
    task_id = str(uuid.uuid4())

    # Create and store the pending task record
    task = TaskResponse(
        task_id=task_id,
        goal=request.goal,
        status=TaskStatus.PENDING,
        priority=request.priority,
    )
    _task_store[task_id] = task

    # Schedule the pipeline as a background task
    background_tasks.add_task(
        _run_pipeline,
        task_id=task_id,
        goal=request.goal,
        context=request.context,
        orchestrator=orchestrator,
        timeout=settings.TASK_TIMEOUT_SECONDS,
    )

    logger.info(
        "Task created and queued: task_id=%s, goal='%s...'",
        task_id, request.goal[:50],
    )
    return task


@router.get(
    "/{task_id}",
    response_model=TaskResponse,
    summary="Get full task status and results",
)
async def get_task(task_id: str) -> TaskResponse:
    """
    GET /api/v1/tasks/{task_id}

    Returns the full task object including all agent results and
    the final output once completed. Clients should poll this endpoint
    at a reasonable interval (e.g., every 5 seconds).
    """
    return _get_task_or_404(task_id)


@router.get(
    "/",
    response_model=list[TaskSummaryResponse],
    summary="List all tasks (lightweight)",
)
async def list_tasks(
    limit: int = 20,
    offset: int = 0,
    status_filter: TaskStatus | None = None,
) -> list[TaskSummaryResponse]:
    """
    GET /api/v1/tasks

    Returns lightweight task summaries (no heavy agent outputs)
    for listing/monitoring purposes. Supports filtering and pagination.
    """
    all_tasks = list(_task_store.values())

    # Sort newest first
    all_tasks.sort(key=lambda t: t.created_at, reverse=True)

    # Optional status filter
    if status_filter:
        all_tasks = [t for t in all_tasks if t.status == status_filter]

    # Pagination
    paginated = all_tasks[offset : offset + limit]

    return [
        TaskSummaryResponse(
            task_id=t.task_id,
            goal=t.goal,
            status=t.status,
            priority=t.priority,
            created_at=t.created_at,
            completed_at=t.completed_at,
        )
        for t in paginated
    ]


@router.delete(
    "/{task_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Cancel or delete a task",
)
async def delete_task(task_id: str) -> None:
    """
    DELETE /api/v1/tasks/{task_id}

    Removes the task record. Running pipelines cannot be cancelled
    mid-execution (would require task queue infrastructure in production).
    """
    task = _get_task_or_404(task_id)

    if task.status == TaskStatus.RUNNING:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Cannot delete a running task. Wait for completion or timeout.",
        )

    del _task_store[task_id]
    logger.info("Task deleted: task_id=%s", task_id)
