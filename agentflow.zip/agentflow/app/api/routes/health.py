"""
health.py — Health Check Endpoints

WHY HEALTH ENDPOINTS MATTER:
    In containerized production deployments (Kubernetes, ECS, Cloud Run),
    the infrastructure needs to know if our service is healthy.
    Without proper health checks:
    - K8s can't restart crashed pods (liveness probe)
    - Load balancers route traffic to unhealthy instances (readiness probe)
    - On-call engineers have no visibility during incidents

    We implement two standard probes:
    • /health/live  → "Am I running?" (liveness — just check process is up)
    • /health/ready → "Can I serve traffic?" (readiness — check all deps)
"""

import logging

from fastapi import APIRouter, status
from fastapi.responses import JSONResponse

from app.config.settings import get_settings
from app.memory.vector_store import get_vector_memory
from app.models.task import HealthResponse

logger = logging.getLogger(__name__)
settings = get_settings()

router = APIRouter(prefix="/health", tags=["Health"])


@router.get(
    "/live",
    response_model=HealthResponse,
    summary="Liveness probe — is the service alive?",
)
async def liveness() -> HealthResponse:
    """
    Kubernetes liveness probe.
    Returns 200 if the process is running. Never checks external dependencies —
    a slow DB shouldn't cause a liveness failure and trigger a restart loop.
    """
    return HealthResponse(
        status="healthy",
        version=settings.APP_VERSION,
        environment=settings.APP_ENV,
    )


@router.get(
    "/ready",
    summary="Readiness probe — can the service handle traffic?",
)
async def readiness() -> JSONResponse:
    """
    Kubernetes readiness probe.
    Checks all critical external dependencies. Returns 503 if any are down,
    causing the load balancer to stop routing traffic until recovery.
    """
    service_status: dict[str, str] = {}
    all_healthy = True

    # ── Check ChromaDB ─────────────────────────────────────────────────
    try:
        memory = get_vector_memory()
        chroma_ok = memory.health_check()
        service_status["chromadb"] = "healthy" if chroma_ok else "unhealthy"
        if not chroma_ok:
            all_healthy = False
    except Exception as exc:
        service_status["chromadb"] = f"error: {str(exc)[:100]}"
        all_healthy = False

    # ── Check OpenAI Key (existence, not validity) ──────────────────────
    service_status["openai_key"] = "configured" if settings.OPENAI_API_KEY else "missing"
    if not settings.OPENAI_API_KEY:
        all_healthy = False

    http_status = status.HTTP_200_OK if all_healthy else status.HTTP_503_SERVICE_UNAVAILABLE

    return JSONResponse(
        status_code=http_status,
        content={
            "status": "ready" if all_healthy else "degraded",
            "version": settings.APP_VERSION,
            "environment": settings.APP_ENV,
            "services": service_status,
        },
    )
