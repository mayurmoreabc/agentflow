"""
tests/test_agents.py — Unit Tests for Agent Logic

WHY UNIT TESTS FOR AGENTS:
    Agents are the most complex, expensive, and failure-prone parts of the system.
    Unit tests with mocked LLM responses let us:
    • Test agent logic without making real API calls (fast + free)
    • Simulate failure cases (LLM timeout, malformed JSON, empty responses)
    • Verify that agents correctly parse and structure their outputs
"""

import json
import pytest
from unittest.mock import AsyncMock, MagicMock, patch

from app.models.task import AgentRole


class TestReviewerScoring:
    """Tests for ReviewerAgent's scoring and parsing logic."""

    def test_score_weights_sum_to_one(self):
        """Reviewer's dimension weights must sum to 1.0 for valid weighting."""
        from app.agents.reviewer import ReviewerAgent
        total = sum(ReviewerAgent.SCORE_WEIGHTS.values())
        assert abs(total - 1.0) < 0.001, f"Weights sum to {total}, expected 1.0"

    def test_parse_valid_scorecard(self):
        """_parse_scorecard should correctly extract decision and scores."""
        from app.agents.reviewer import ReviewerAgent

        reviewer = ReviewerAgent()
        valid_json = json.dumps({
            "scores": {
                "accuracy": 0.9,
                "completeness": 0.8,
                "clarity": 0.85,
                "structure": 0.8,
                "actionability": 0.75,
            },
            "overall_score": 0.84,
            "decision": "APPROVED",
            "strengths": ["Well structured"],
            "required_changes": [],
            "feedback_for_writer": "Excellent work.",
        })

        result = reviewer._parse_scorecard(valid_json, revision_count=0)
        assert result["decision"] == "APPROVED"
        assert result["overall_score"] > 0.7

    def test_parse_json_with_markdown_fences(self):
        """Parser should strip ```json fences that LLMs sometimes add."""
        from app.agents.reviewer import ReviewerAgent

        reviewer = ReviewerAgent()
        # LLMs often wrap JSON in code fences despite being told not to
        wrapped_json = """```json
{
  "scores": {"accuracy": 0.8, "completeness": 0.7, "clarity": 0.75, "structure": 0.8, "actionability": 0.6},
  "overall_score": 0.73,
  "decision": "REVISION_REQUIRED",
  "strengths": [],
  "required_changes": ["Add more detail"],
  "feedback_for_writer": "Needs more content."
}
```"""
        result = reviewer._parse_scorecard(wrapped_json, revision_count=0)
        assert result["decision"] == "REVISION_REQUIRED"

    def test_auto_approve_after_max_revisions(self):
        """After 2 revisions, the reviewer should auto-approve to prevent infinite loops."""
        from app.agents.reviewer import ReviewerAgent

        reviewer = ReviewerAgent()
        scorecard_json = json.dumps({
            "scores": {dim: 0.65 for dim in ReviewerAgent.SCORE_WEIGHTS},
            "overall_score": 0.65,
            "decision": "REVISION_REQUIRED",
            "strengths": [],
            "required_changes": ["Still needs work"],
            "feedback_for_writer": "...",
        })

        # After revision_count=2, should auto-approve if score > 0.6
        result = reviewer._parse_scorecard(scorecard_json, revision_count=2)
        assert result["decision"] == "APPROVED"
        assert result.get("auto_approved") is True

    def test_parse_invalid_json_returns_fallback(self):
        """Malformed JSON should not crash — return a safe fallback scorecard."""
        from app.agents.reviewer import ReviewerAgent

        reviewer = ReviewerAgent()
        result = reviewer._parse_scorecard("this is not json {{{", revision_count=0)

        # Fallback should have all required fields
        assert "decision" in result
        assert "overall_score" in result
        assert "feedback_for_writer" in result
        assert result.get("parse_error") is True


class TestResearcherChunking:
    """Tests for ResearcherAgent's text chunking logic."""

    def test_chunk_short_text(self):
        """Short texts that fit in one chunk should return single-element list."""
        from app.agents.researcher import ResearcherAgent

        short_text = "This is a short piece of research text with fewer than 500 words."
        chunks = ResearcherAgent._chunk_text(short_text, chunk_size=500)
        assert len(chunks) == 1
        assert chunks[0] == short_text

    def test_chunk_long_text_produces_multiple(self):
        """Long texts should be split into multiple overlapping chunks."""
        from app.agents.researcher import ResearcherAgent

        # 600 words of text
        long_text = " ".join([f"word{i}" for i in range(600)])
        chunks = ResearcherAgent._chunk_text(long_text, chunk_size=200)
        assert len(chunks) > 1

    def test_chunks_have_overlap(self):
        """Consecutive chunks should share some words (overlap for continuity)."""
        from app.agents.researcher import ResearcherAgent

        words = [f"word{i}" for i in range(400)]
        long_text = " ".join(words)
        chunks = ResearcherAgent._chunk_text(long_text, chunk_size=200)

        if len(chunks) > 1:
            # Last words of chunk 1 should appear in beginning of chunk 2
            chunk1_words = set(chunks[0].split())
            chunk2_words = set(chunks[1].split())
            overlap = chunk1_words & chunk2_words
            assert len(overlap) > 0, "Chunks should have word overlap"


class TestAgentModels:
    """Tests for task model validation."""

    def test_create_task_request_cleans_whitespace(self):
        """Goal validator should strip leading/trailing whitespace."""
        from app.models.task import CreateTaskRequest

        req = CreateTaskRequest(goal="  Research AI trends thoroughly  ")
        assert req.goal == "Research AI trends thoroughly"

    def test_create_task_rejects_one_word_goal(self):
        """Goals with fewer than 3 words should raise ValueError."""
        from app.models.task import CreateTaskRequest
        from pydantic import ValidationError

        with pytest.raises(ValidationError):
            CreateTaskRequest(goal="Research")

    def test_agent_role_enum_values(self):
        """AgentRole enum must have all required roles."""
        from app.models.task import AgentRole

        roles = {r.value for r in AgentRole}
        assert "researcher" in roles
        assert "writer" in roles
        assert "reviewer" in roles
        assert "orchestrator" in roles
