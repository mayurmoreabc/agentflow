"""
tests/test_api.py — Integration Tests for the FastAPI Layer

WHY TESTS IN A PORTFOLIO PROJECT:
    Tests are the #1 indicator of professional engineering. They show:
    1. You think about correctness, not just "it works on my machine"
    2. You understand API contracts and edge cases
    3. Your code is testable (good architecture signal)

    Most junior engineers skip tests. Having them makes you stand out.

HOW FASTAPI TESTING WORKS:
    FastAPI's TestClient wraps httpx to make synchronous requests to
    the async app in tests. No server needs to be running.
"""

import pytest
from unittest.mock import AsyncMock, MagicMock, patch
from fastapi.testclient import TestClient

from app import create_app
from app.models.task import TaskStatus


@pytest.fixture
def client():
    """Creates a TestClient with a fresh app instance per test."""
    app = create_app()
    return TestClient(app)


class TestHealthEndpoints:
    """Tests for /health/live and /health/ready endpoints."""

    def test_liveness_returns_200(self, client):
        """Liveness probe should always return 200 when process is running."""
        response = client.get("/api/v1/health/live")
        assert response.status_code == 200
        data = response.json()
        assert data["status"] == "healthy"
        assert "version" in data

    def test_liveness_returns_version(self, client):
        """Version field should be present for observability."""
        response = client.get("/api/v1/health/live")
        data = response.json()
        assert data["version"] == "1.0.0"


class TestTaskCreation:
    """Tests for POST /api/v1/tasks — task creation."""

    def test_create_task_returns_202(self, client):
        """
        Task creation should return 202 Accepted (not 200 OK).
        202 signals async processing — the resource isn't ready yet.
        """
        response = client.post(
            "/api/v1/tasks",
            json={"goal": "Research the history of artificial intelligence in detail"}
        )
        assert response.status_code == 202

    def test_create_task_returns_task_id(self, client):
        """Response must include a task_id for the client to poll."""
        response = client.post(
            "/api/v1/tasks",
            json={"goal": "Analyze the competitive landscape of cloud computing"}
        )
        data = response.json()
        assert "task_id" in data
        assert len(data["task_id"]) == 36  # UUID4 length

    def test_create_task_initial_status_is_pending(self, client):
        """Newly created tasks must start in PENDING state."""
        response = client.post(
            "/api/v1/tasks",
            json={"goal": "Write a report on machine learning trends"}
        )
        data = response.json()
        assert data["status"] == TaskStatus.PENDING.value

    def test_create_task_rejects_too_short_goal(self, client):
        """Validation should reject goals with fewer than 3 words."""
        response = client.post(
            "/api/v1/tasks",
            json={"goal": "hi"}
        )
        assert response.status_code == 422

    def test_create_task_rejects_empty_goal(self, client):
        """Empty goals should fail validation."""
        response = client.post(
            "/api/v1/tasks",
            json={"goal": ""}
        )
        assert response.status_code == 422

    def test_create_task_with_context(self, client):
        """Tasks with optional context should be accepted."""
        response = client.post(
            "/api/v1/tasks",
            json={
                "goal": "Research OpenAI's GPT-5 release strategy",
                "context": "Focus on enterprise adoption and pricing implications",
                "priority": "high"
            }
        )
        assert response.status_code == 202

    def test_create_task_with_invalid_priority(self, client):
        """Invalid priority values should be rejected by Pydantic."""
        response = client.post(
            "/api/v1/tasks",
            json={
                "goal": "Research something interesting and important",
                "priority": "ultra_critical"  # Invalid enum value
            }
        )
        assert response.status_code == 422


class TestTaskRetrieval:
    """Tests for GET /api/v1/tasks/{task_id}."""

    def test_get_nonexistent_task_returns_404(self, client):
        """Missing tasks must return 404, not 500."""
        response = client.get("/api/v1/tasks/nonexistent-task-id")
        assert response.status_code == 404

    def test_get_task_after_creation(self, client):
        """Created task should be retrievable by its ID."""
        # Create a task
        create_resp = client.post(
            "/api/v1/tasks",
            json={"goal": "Research quantum computing breakthroughs in 2024"}
        )
        task_id = create_resp.json()["task_id"]

        # Retrieve it
        get_resp = client.get(f"/api/v1/tasks/{task_id}")
        assert get_resp.status_code == 200
        assert get_resp.json()["task_id"] == task_id

    def test_list_tasks_returns_array(self, client):
        """Task listing should return a JSON array."""
        response = client.get("/api/v1/tasks/")
        assert response.status_code == 200
        assert isinstance(response.json(), list)


class TestInputValidation:
    """Tests for edge cases in input validation."""

    def test_goal_strip_whitespace(self, client):
        """Goals with leading/trailing whitespace should be cleaned."""
        response = client.post(
            "/api/v1/tasks",
            json={"goal": "   Research blockchain technology applications   "}
        )
        assert response.status_code == 202

    def test_goal_max_length_enforced(self, client):
        """Goals exceeding 2000 characters should be rejected."""
        long_goal = "a " * 1001  # 2002 chars
        response = client.post(
            "/api/v1/tasks",
            json={"goal": long_goal}
        )
        assert response.status_code == 422
